package com.mahi.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
